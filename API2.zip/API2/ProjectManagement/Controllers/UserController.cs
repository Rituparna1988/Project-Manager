﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ProjectManagement.Models;
using System.Web.Http.Cors;

namespace ProjectManagement.Controllers
{
    [EnableCors(origins: "http://localhost:55887/api/user/", headers: "*", methods: "*")]
    public class UserController : ApiController
    {
        private ProjectManagementEntities db = new ProjectManagementEntities();

        // GET api/User
        public IQueryable<tblUser> GetUsers()
        {
            return db.tblUsers;
        }

        // GET api/User/5
        [ResponseType(typeof(tblUser))]
        public IHttpActionResult GetUser(int id)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            if (tbluser == null)
            {
                return NotFound();
            }

            return Ok(tbluser);
        }

        // PUT api/User/5
        public IHttpActionResult PutUser(int id, tblUser tbluser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbluser.User_ID)
            {
                return BadRequest();
            }

            db.Entry(tbluser).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tblUserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/User
        [ResponseType(typeof(tblUser))]
        public IHttpActionResult PostUser(tblUser tbluser)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tblUsers.Add(tbluser);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tbluser.User_ID }, tbluser);
        }

        // DELETE api/User/5
        [ResponseType(typeof(tblUser))]
        public IHttpActionResult DeleteUser(int id)
        {
            tblUser tbluser = db.tblUsers.Find(id);
            if (tbluser == null)
            {
                return NotFound();
            }

            db.tblUsers.Remove(tbluser);
            db.SaveChanges();

            return Ok(tbluser);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tblUserExists(int id)
        {
            return db.tblUsers.Count(e => e.User_ID == id) > 0;
        }
    }
}