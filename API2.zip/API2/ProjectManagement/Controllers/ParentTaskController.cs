﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ProjectManagement.Models;

namespace ProjectManagement.Controllers
{
    public class ParentTaskController : ApiController
    {
        private ProjectManagementEntities db = new ProjectManagementEntities();

        // GET api/ParentTask
        public IQueryable<tblParentTask> GetParentTasks()
        {
            return db.tblParentTasks;
        }

        // GET api/ParentTask/5
        [ResponseType(typeof(tblParentTask))]
        public IHttpActionResult GetParentTask(int id)
        {
            tblParentTask tblparenttask = db.tblParentTasks.Find(id);
            if (tblparenttask == null)
            {
                return NotFound();
            }

            return Ok(tblparenttask);
        }

        // PUT api/ParentTask/5
        public IHttpActionResult PutParentTask(int id, tblParentTask tblparenttask)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tblparenttask.Parent_ID)
            {
                return BadRequest();
            }

            db.Entry(tblparenttask).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tblParentTaskExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/ParentTask
        [ResponseType(typeof(tblParentTask))]
        public IHttpActionResult PostParentTask(tblParentTask tblparenttask)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tblParentTasks.Add(tblparenttask);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (tblParentTaskExists(tblparenttask.Parent_ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = tblparenttask.Parent_ID }, tblparenttask);
        }

        // DELETE api/ParentTask/5
        [ResponseType(typeof(tblParentTask))]
        public IHttpActionResult DeleteParentTask(int id)
        {
            tblParentTask tblparenttask = db.tblParentTasks.Find(id);
            if (tblparenttask == null)
            {
                return NotFound();
            }

            db.tblParentTasks.Remove(tblparenttask);
            db.SaveChanges();

            return Ok(tblparenttask);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tblParentTaskExists(int id)
        {
            return db.tblParentTasks.Count(e => e.Parent_ID == id) > 0;
        }
    }
}