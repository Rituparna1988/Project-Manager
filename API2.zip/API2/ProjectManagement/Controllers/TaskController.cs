﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ProjectManagement.Models;

namespace ProjectManagement.Controllers
{
    public class TaskController : ApiController
    {
        private ProjectManagementEntities db = new ProjectManagementEntities();

        // GET api/Task
        public IQueryable<tblTask> GettblTasks()
        {
            return db.tblTasks;
        }

        // GET api/Task/5
        [ResponseType(typeof(tblTask))]
        public IHttpActionResult GetTask(int id)
        {
            tblTask tbltask = db.tblTasks.Find(id);
            if (tbltask == null)
            {
                return NotFound();
            }

            return Ok(tbltask);
        }

        // PUT api/Task/5
        public IHttpActionResult PutTask(int id, tblTask tbltask)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbltask.Task_ID)
            {
                return BadRequest();
            }

            db.Entry(tbltask).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tblTaskExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Task
        [ResponseType(typeof(tblTask))]
        public IHttpActionResult PostTask(tblTask tbltask)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tblTasks.Add(tbltask);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (tblTaskExists(tbltask.Task_ID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = tbltask.Task_ID }, tbltask);
        }

        // DELETE api/Task/5
        [ResponseType(typeof(tblTask))]
        public IHttpActionResult DeleteTask(int id)
        {
            tblTask tbltask = db.tblTasks.Find(id);
            if (tbltask == null)
            {
                return NotFound();
            }

            db.tblTasks.Remove(tbltask);
            db.SaveChanges();

            return Ok(tbltask);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tblTaskExists(int id)
        {
            return db.tblTasks.Count(e => e.Task_ID == id) > 0;
        }
    }
}