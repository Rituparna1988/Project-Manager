﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ProjectManagement.Models;

namespace ProjectManagement.Controllers
{
    public class ProjectController : ApiController
    {
        private ProjectManagementEntities db = new ProjectManagementEntities();

        // GET api/Project
        public IQueryable<tblProject> GetProjects()
        {
            return db.tblProjects;
        }

        // GET api/Project/5
        [ResponseType(typeof(tblProject))]
        public IHttpActionResult GetProject(int id)
        {
            tblProject tblproject = db.tblProjects.Find(id);
            if (tblproject == null)
            {
                return NotFound();
            }

            return Ok(tblproject);
        }

        // PUT api/Project/5
        public IHttpActionResult PutProject(int id, tblProject tblproject)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tblproject.Project_ID)
            {
                return BadRequest();
            }

            db.Entry(tblproject).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tblProjectExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Project
        [ResponseType(typeof(tblProject))]
        public IHttpActionResult PostProject(tblProject tblproject)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tblProjects.Add(tblproject);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tblproject.Project_ID }, tblproject);
        }

        // DELETE api/Project/5
        [ResponseType(typeof(tblProject))]
        public IHttpActionResult DeleteProject(int id)
        {
            tblProject tblproject = db.tblProjects.Find(id);
            if (tblproject == null)
            {
                return NotFound();
            }

            db.tblProjects.Remove(tblproject);
            db.SaveChanges();

            return Ok(tblproject);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tblProjectExists(int id)
        {
            return db.tblProjects.Count(e => e.Project_ID == id) > 0;
        }
    }
}