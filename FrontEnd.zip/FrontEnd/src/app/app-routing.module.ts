import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './components/user/user.component';
import { ProjectComponent } from './components/project/project.component';
import { TaskComponent } from './components/task/task.component';
import { ViewTaskComponent } from './components/view-task/view-task.component';

const routes: Routes = [
  {path: '', redirectTo: '/user', pathMatch: 'full'},
  { path: 'user', component: UserComponent },
  { path: 'project',      component:  ProjectComponent},
  {
    path: 'task',
    component: TaskComponent
  },
  { path: 'view-task',      component:  ViewTaskComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
