import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http: HttpClient) { }

    getProjects(){
     const getProjectsURL = "http://localhost:55887/api/task/";
     return this.http.get(getProjectsURL); 
  }

  addProjects(task){
     const addProjectsURL = "http://localhost:55887/api/task/";
     return this.http.post(addProjectsURL, task);
  }
}