import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: HttpClient
  ) { 

  }

  getUsers(){
     const getUsersURL = "http://localhost:55887/api/user/";
     return this.http.get(getUsersURL); 
  }

  addUsers(user){
     const addUsersURL = "http://localhost:55887/api/user/";
     return this.http.post(addUsersURL, user);
  }
}

