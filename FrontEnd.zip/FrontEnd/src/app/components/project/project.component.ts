import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../../services/project.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {


  projects:[] = [];
  project: object = {};
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    this.getProjects();
  }
  getProjects(){
    this.projectService.getProjects.subscribe((projects =>{
      this.projects = projects;
    }));
  }
  addProjects(){  
    this.projects.Project_ID = 0;
    console.log("Project object", this.projects);

    this.projectService.addProjects(this.projects).subscribe((project)=>{
      console.log(1111111111, project);
    });
    this.getProjects();
  }

}
