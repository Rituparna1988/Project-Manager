import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users:[] = [];
  user: object = {};

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.getUsers();
    
  }
  getUsers(){
    this.userService.getUsers().subscribe((users =>{
      this.users = users;
    }));
  }
  addUser(){    
    this.user.User_ID = 0;
    this.user.Project_ID = 0;
    this.user.Task_ID = '';

    console.log("user object", this.user)

    this.userService.addUsers(this.user).subscribe((user)=>{
      console.log(1111111111, user);
    });
    this.getUsers();
  }
}


